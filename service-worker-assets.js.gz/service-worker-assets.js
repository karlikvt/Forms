﻿self.assetsManifest = {
  "assets": [
    {
      "hash": "sha256-hCgyKYB2Fp3cS2OYfOsDmtYLbOA\/5\/0gZ\/fo0fXNVuo=",
      "url": "_content\/Blazored.Modal\/blazored-modal.css"
    },
    {
      "hash": "sha256-Ecu8rYbiN76vhfIqWT4tzjwbb0xrvEokQNxvlLVzqdw=",
      "url": "_content\/Blazored.Modal\/blazored.modal.js"
    },
    {
      "hash": "sha256-BQCa6WAHgmX3oiww7ONV3v3OboJrhzPzkP2z296EuPo=",
      "url": "css\/app.css"
    },
    {
      "hash": "sha256-YLGeXaapI0\/5IgZopewRJcFXomhRMlYYjugPLSyNjTY=",
      "url": "css\/bootstrap\/bootstrap.min.css"
    },
    {
      "hash": "sha256-xMZ0SaSBYZSHVjFdZTAT\/IjRExRIxSriWcJLcA9nkj0=",
      "url": "css\/bootstrap\/bootstrap.min.css.map"
    },
    {
      "hash": "sha256-+Q44zfEaCMmXduni5Td+IgCbk8sSUQwES2nWs+KKQz0=",
      "url": "css\/open-iconic\/FONT-LICENSE"
    },
    {
      "hash": "sha256-BJ\/G+e+y7bQdrYkS2RBTyNfBHpA9IuGaPmf9htub5MQ=",
      "url": "css\/open-iconic\/font\/css\/open-iconic-bootstrap.min.css"
    },
    {
      "hash": "sha256-OK3poGPgzKI2NzNgP07XMbJa3Dz6USoUh\/chSkSvQpc=",
      "url": "css\/open-iconic\/font\/fonts\/open-iconic.eot"
    },
    {
      "hash": "sha256-sDUtuZAEzWZyv\/U1xl\/9D3ehyU69JE+FvAcu5HQ+\/a0=",
      "url": "css\/open-iconic\/font\/fonts\/open-iconic.otf"
    },
    {
      "hash": "sha256-oUpLdS+SoLJFwf4bzA3iKD7TCm66oLkTpAQlVJ2s1wc=",
      "url": "css\/open-iconic\/font\/fonts\/open-iconic.svg"
    },
    {
      "hash": "sha256-p+RP8CV3vRK1YbIkNzq3rPo1jyETPnR07ULb+HVYL8w=",
      "url": "css\/open-iconic\/font\/fonts\/open-iconic.ttf"
    },
    {
      "hash": "sha256-cZPqVlRJfSNW0KaQ4+UPOXZ\/v\/QzXlejRDwUNdZIofI=",
      "url": "css\/open-iconic\/font\/fonts\/open-iconic.woff"
    },
    {
      "hash": "sha256-s\/Is6Ey6jfNAEfXUIOyHrXXX+RcA8hzchYnuOIWUMl4=",
      "url": "css\/open-iconic\/ICON-LICENSE"
    },
    {
      "hash": "sha256-9wdNXQFE78LCNHo+Hq2eXMTx+YBf2gjsufVTJc8dAV0=",
      "url": "css\/open-iconic\/README.md"
    },
    {
      "hash": "sha256-IJWY3tt5Zt3h097q6QT12PXYLiwEPxR0iPGF1mQ8TTs=",
      "url": "favicon.ico"
    },
    {
      "hash": "sha256-qU+KhVPK6oQw3UyjzAHU4xjRmCj3TLZUU\/+39dni9E0=",
      "url": "faviconDefault.ico"
    },
    {
      "hash": "sha256-IpHFcQvs03lh6W54zoeJRG1jW+VnGmwymzxLoXtKX7Y=",
      "url": "icon-512.png"
    },
    {
      "hash": "sha256-U9VwnS37b0dtmK6gswiZNeSWBukpfJsq\/Gl2pRvNE2k=",
      "url": "icons\/icon-192x192.png"
    },
    {
      "hash": "sha256-HH6ZLa1rEqvXyWzSmBlzFEilnFpmFSPNPKhEvmpvtxA=",
      "url": "icons\/icon-512x512.png"
    },
    {
      "hash": "sha256-PvE1MHPpU5yi2KQA2VLP7TKeTno6f5CFWH03Xm0kZlI=",
      "url": "icons\/logo.PNG"
    },
    {
      "hash": "sha256-jX\/cY+kvp8v3XSTrPJ9ifyZkYv9PynKP8DFyMkXs\/0g=",
      "url": "icons\/logoCheck.png"
    },
    {
      "hash": "sha256-x5v0zunfMyXw5oNOd2AraLnt\/oSjhoeIEF6lI7xk7+c=",
      "url": "images\/logo.PNG"
    },
    {
      "hash": "sha256-dd4Bu4whgMx+9eqwJo5WRtAiq9\/k2SbrgYmUu6OXH0E=",
      "url": "index.html"
    },
    {
      "hash": "sha256-9KLuD1DIAJGl955Q+UZn\/yuMfh928kTib5Rpkz4kAe0=",
      "url": "jsInterop.js"
    },
    {
      "hash": "sha256-F0WZ7jso87ys8V9fENY8aExbuDl9xhSf6eetAQCFZOc=",
      "url": "jspdf.min.js"
    },
    {
      "hash": "sha256-cHZOY3BqTvVszwWrLCO9xAkP0DSFsaogpoQ5WWH51bU=",
      "url": "manifest.json"
    },
    {
      "hash": "sha256-4Yh4OTT5TEAPNyXEzOG+n5l2HPK294WFItz4SIelj88=",
      "url": "sample-data\/weather.json"
    },
    {
      "hash": "sha256-2kSAx96AY\/qfQS2BbCmvNY\/ipja+CS0bQtBidP4W3jE=",
      "url": "signatur.js"
    },
    {
      "hash": "sha256-0eiAUt6AY52XU1Z+3fSSvRxpmuEUZmfSaq6dCv3L8kU=",
      "url": "_framework\/_bin\/Blazored.Modal.dll"
    },
    {
      "hash": "sha256-9gWBHUG5THZx3ay3GYEO\/A7oSAXvCc0z0EN\/RafQBvQ=",
      "url": "_framework\/_bin\/Forms.dll"
    },
    {
      "hash": "sha256-vPSTOx+iZMAGjs8f+VXANrsUKzV8QF2NBn7Gxadqwys=",
      "url": "_framework\/_bin\/Microsoft.AspNetCore.Components.dll"
    },
    {
      "hash": "sha256-hLoR2dtpzekTBXl3GhtRCyPyS58xDAHqCt4QWuYzRXc=",
      "url": "_framework\/_bin\/Microsoft.AspNetCore.Components.Web.dll"
    },
    {
      "hash": "sha256-0YO7iDnbWzID\/8IEe2hHrhEyeTOyTftBzx4y6j+Vy4Y=",
      "url": "_framework\/_bin\/Microsoft.AspNetCore.Components.WebAssembly.dll"
    },
    {
      "hash": "sha256-tSgpHMMPulJycSElSBCjmXU3qQ1hwOc8Tw5dwpjOBBI=",
      "url": "_framework\/_bin\/Microsoft.Bcl.AsyncInterfaces.dll"
    },
    {
      "hash": "sha256-+UsOLX1uNyGTdcHRdh2\/BocSFe0DBt55aT+Xg2VV17o=",
      "url": "_framework\/_bin\/Microsoft.Extensions.Configuration.Abstractions.dll"
    },
    {
      "hash": "sha256-add21m4M\/dpSOrGrysvBzfasYBXsZhK5Gpbax30xe7Q=",
      "url": "_framework\/_bin\/Microsoft.Extensions.Configuration.dll"
    },
    {
      "hash": "sha256-+6nqJsBloyJPAx+ridCWD5sFgXAmaIDiMDZKHnkXjNA=",
      "url": "_framework\/_bin\/Microsoft.Extensions.Configuration.Json.dll"
    },
    {
      "hash": "sha256-I2lj1D2VPnTGwqmP36S1Y9EIJDoJF9\/TCvoprz9xQQA=",
      "url": "_framework\/_bin\/Microsoft.Extensions.DependencyInjection.Abstractions.dll"
    },
    {
      "hash": "sha256-xgqxPfFbw5Q8Ig9nqtFwtCu0xKe+x\/NyBVp814+ZKf8=",
      "url": "_framework\/_bin\/Microsoft.Extensions.DependencyInjection.dll"
    },
    {
      "hash": "sha256-L6p39ekEnDNqmkXwNjVvw\/cXfOZBCh7l\/ipmY0oRdIc=",
      "url": "_framework\/_bin\/Microsoft.Extensions.Logging.Abstractions.dll"
    },
    {
      "hash": "sha256-jDHSd98cJCvR4XtyTroGV2A75tjuv4ch77LNpP4g+GY=",
      "url": "_framework\/_bin\/Microsoft.Extensions.Logging.dll"
    },
    {
      "hash": "sha256-602ETGSdjMS\/kUDYWOiLmjsRBng4kI9XN3kb47d0sRM=",
      "url": "_framework\/_bin\/Microsoft.Extensions.Options.dll"
    },
    {
      "hash": "sha256-fU1hCdWE5ob9IY4nzbDI3DEval2FJhxuVmQX\/Lxvvfg=",
      "url": "_framework\/_bin\/Microsoft.Extensions.Primitives.dll"
    },
    {
      "hash": "sha256-E8gUY7MFiQ8atK5cwJ\/UYJqli\/JKChg4NOA9Zv1wvg0=",
      "url": "_framework\/_bin\/Microsoft.JSInterop.dll"
    },
    {
      "hash": "sha256-+KWE26a13qSccwagT2uBJ76PQC2RBwyGEHATmbt+4+8=",
      "url": "_framework\/_bin\/Microsoft.JSInterop.WebAssembly.dll"
    },
    {
      "hash": "sha256-5XJZq8YMjXivZsEpJoCf7uSv7jbuX3RgVE\/vr0WQ57Y=",
      "url": "_framework\/_bin\/mscorlib.dll"
    },
    {
      "hash": "sha256-IAC9e9ZM4pjnrUwfBd6VxNsyvcBZFah821W2RHeQwuE=",
      "url": "_framework\/_bin\/System.Core.dll"
    },
    {
      "hash": "sha256-37e4uo0SuWs6+9GWKfnExC\/eBAUBMtY1argQW4Q7f34=",
      "url": "_framework\/_bin\/System.dll"
    },
    {
      "hash": "sha256-k6DmDnhYY7q1x2pWpf6co+yiVrjFEtjYL6hzPKD42V4=",
      "url": "_framework\/_bin\/System.Net.Http.dll"
    },
    {
      "hash": "sha256-oo+TtMZ8DS7HoDPak\/A1RB8GUhSsFcErFrHzfWeEFI4=",
      "url": "_framework\/_bin\/System.Net.Http.Json.dll"
    },
    {
      "hash": "sha256-v\/EVGTq0SV5l6Sdn9XXCUcHah+yp5J6aFrSlCQkUnpM=",
      "url": "_framework\/_bin\/System.Net.Http.WebAssemblyHttpHandler.dll"
    },
    {
      "hash": "sha256-Rw\/+q9Oer6RXDVmAPew3N9wmCmVjgFsn5uCITTQT+yM=",
      "url": "_framework\/_bin\/System.Runtime.CompilerServices.Unsafe.dll"
    },
    {
      "hash": "sha256-aQWV2Gfl06EdSRVNg0crcZXZvdoqFLVxEWHebyKVxgw=",
      "url": "_framework\/_bin\/System.Text.Encodings.Web.dll"
    },
    {
      "hash": "sha256-XI4wGUgA+9ti5j\/i4LZGyzye8VPtMr\/3C1+2P2YJngs=",
      "url": "_framework\/_bin\/System.Text.Json.dll"
    },
    {
      "hash": "sha256-Ooau7pfCRMWqeNJiBqZc+YwX7ya7y+C8ngfq3gkNq24=",
      "url": "_framework\/_bin\/WebAssembly.Bindings.dll"
    },
    {
      "hash": "sha256-mPoqx7XczFHBWk3gRNn0hc9ekG1OvkKY4XiKRY5Mj5U=",
      "url": "_framework\/wasm\/dotnet.3.2.0.js"
    },
    {
      "hash": "sha256-3S0qzYaBEKOBXarzVLNzNAFXlwJr6nI3lFlYUpQTPH8=",
      "url": "_framework\/wasm\/dotnet.timezones.dat"
    },
    {
      "hash": "sha256-UC\/3Rm1NkdNdlIrzYARo+dO\/HDlS5mhPxo0IQv7kma8=",
      "url": "_framework\/wasm\/dotnet.wasm"
    },
    {
      "hash": "sha256-SPHS1EAPAcMFN4TEIUYl3FWtoCQTsNJch0XVGgok1eE=",
      "url": "_framework\/blazor.webassembly.js"
    },
    {
      "hash": "sha256-ZPeXCFg2F\/46ylS3kNP\/tgHqrTA09oXcTuxHBb+gjVY=",
      "url": "_framework\/blazor.boot.json"
    }
  ],
  "version": "oFkaeFuf"
};
